package com.airbnb.model;

public class UserDAO {
	
	
	

}
