package com.airbnb.model;

public class UserDTO {
	
	
	

}
