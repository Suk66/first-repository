package com.admin.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.airbnb.controller.Action;
import com.airbnb.controller.ActionForward;
import com.airbnb.model.AdminDAO;
import com.airbnb.model.AdminDTO;

public class AdminNewOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		String admin_id = request.getParameter("admin_id").trim();
		
		String admin_pwd = request.getParameter("admin_pwd").trim();
		
		String admin_name = request.getParameter("admin_name").trim();
		
		String admin_email = request.getParameter("admin_email").trim();
		
		String admin_phone = request.getParameter("admin_phone").trim();
		
		AdminDAO dao = AdminDAO.getInstance();
		
		
		
		
		// adminDAO 의 AdminNew() insert into 문을 만들자.
		
		AdminDTO dto = new AdminDTO();
        dto.setAdmin_id(admin_id);
        dto.setAdmin_pwd(admin_pwd);
        dto.setAdmin_name(admin_name);
        dto.setAdmin_email(admin_email);
        dto.setAdmin_phone(admin_phone);
		
		
		AdminDTO insertAdmin = dao.AdminNew(dto);
		
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		
		ActionForward forward = new ActionForward();
		
		System.out.println("AdminNewOkAction: insertAdmin = " + insertAdmin);
		if(insertAdmin != null) {
			
			session.setAttribute("adminNew", insertAdmin);
			
			forward.setRedirect(false);
			forward.setPath("/admin/adminDetail.jsp");
			System.out.println("ActionForward set to /admin/adminDetail.jsp");
			
		}else {
			System.out.println("AdminNewOkAction: AdminDTO creation failed!");
			
			// 삽입 실패 시 처리
            out.println("<script>");
            out.println("alert('관리자 추가 실패!');");
            out.println("history.back();");
            out.println("</script>");
			
		}
		
		
		return forward;
	}

}
